﻿using SmartDeliver2.Models;
using SmartDeliver2.Services;
using SmartDeliver2.Services.Etats;
using SmartDeliver2.Services.Observers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SmartDeliverUI
{
    public partial class Form1 : Form
    {
        private Commande commande;
        private ClientObserver observer;

        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnCommander_Click(object sender, EventArgs e)
        {
            commande = new Commande
            {
                Client = txtNom.Text,
                Adresse = txtAdress.Text
            };

            var type = comboType.SelectedItem?.ToString();

            var livraison = LivraisonFactory.CreateLivraison(type);

            lblPrix.Text = "Prix : " + livraison.CalculerPrix() + "$";

            observer = new ClientObserver(commande.Client);
            commande.AjouterObserver(observer);

            commande.SetEtat(new EnAttenteState());

            lblEtat.Text = "Etat : En attente ⏳";
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (commande == null) return;

            commande.ProchainEtat();

            lblEtat.Text = "Etat : " + commande.EtatNom;
        }
    }
    }


