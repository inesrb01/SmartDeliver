﻿using SmartDeliver2.Models;
using SmartDeliver2.Services;
using SmartDeliver2.Services.Etats;
using SmartDeliver2.Services.Observers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace SmartDeliver2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            while (true)
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("=== SMART DELIVER ===");
                Console.ResetColor();

                Console.WriteLine("1. Créer une commande");
                Console.WriteLine("2. Quitter");

                Console.Write("\nChoix : ");
                string choix = Console.ReadLine();

                if (choix == "1")
                    LancerCommande();
                else
                    break;
            }
        }

        static void LancerCommande()
        {
            Console.Clear();

            Console.Write("Nom client : ");
            string nom = Console.ReadLine();

            Console.Write("Adresse : ");
            string adresse = Console.ReadLine();

            var listeMedicaments = new List<Medicament>
            {
                new Medicament { Nom = "Paracetamol", Prix = 5 },
                new Medicament { Nom = "Ibuprofene", Prix = 8 },
                new Medicament { Nom = "Vitamine C", Prix = 10 },
                new Medicament { Nom = "Sirop toux", Prix = 12 }
            };

            var panier = new List<Medicament>();

            // 🔥 PANIER INTERACTIF
            while (true)
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("=== PANIER ===\n");
                Console.ResetColor();

                if (panier.Count == 0)
                {
                    Console.WriteLine("Panier vide");
                }
                else
                {
                    for (int i = 0; i < panier.Count; i++)
                    {
                        var med = panier[i];
                        Console.WriteLine($"{i + 1}. {med.Nom} x{med.Quantite} = {med.Prix * med.Quantite}$");
                    }
                }

                Console.WriteLine("\n--- ACTIONS ---");
                Console.WriteLine("1. Ajouter médicament");
                Console.WriteLine("2. Modifier quantité");
                Console.WriteLine("3. Supprimer médicament");
                Console.WriteLine("0. Terminer");

                Console.Write("\nChoix : ");
                int choix;
                if (!int.TryParse(Console.ReadLine(), out choix)) continue;

                if (choix == 0) break;

                switch (choix)
                {
                    case 1:
                        AjouterMedicament(panier, listeMedicaments);
                        break;

                    case 2:
                        ModifierQuantite(panier);
                        break;

                    case 3:
                        SupprimerMedicament(panier);
                        break;
                }
            }

            double totalMed = panier.Sum(m => m.Prix * m.Quantite);

            Console.Clear();
            Console.WriteLine("=== RECAP COMMANDE ===\n");

            foreach (var med in panier)
            {
                Console.WriteLine($"- {med.Nom} x{med.Quantite} : {med.Prix * med.Quantite}$");
            }

            Console.WriteLine($"\nTotal médicaments : {totalMed}$");

            Console.WriteLine("\nType livraison :");
            Console.WriteLine("1. Standard (+5$)");
            Console.WriteLine("2. Express (+10$)");

            string choixLiv = Console.ReadLine();
            string type = choixLiv == "2" ? "Express" : "Standard";

            var livraison = LivraisonFactory.Creer(type);
            double totalFinal = livraison.CalculerTotal(totalMed);

            Console.WriteLine($"\nTotal final : {totalFinal}$");

            Commande commande = new Commande
            {
                Client = nom,
                Adresse = adresse,
                Medicaments = panier
            };

            var observer = new ClientObserver(nom);
            commande.AjouterObserver(observer);

            commande.SetEtat(new EnAttenteState());

            Animation("Préparation");
            commande.ProchainEtat();

            Animation("Livraison en cours");
            commande.ProchainEtat();

            Animation("Livré");

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\nCommande terminée !");
            Console.ResetColor();

            Console.ReadKey();
        }

        static void AjouterMedicament(List<Medicament> panier, List<Medicament> liste)
        {
            Console.Clear();
            Console.WriteLine("=== AJOUT MEDICAMENT ===\n");

            for (int i = 0; i < liste.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {liste[i].Nom} - {liste[i].Prix}$");
            }

            Console.Write("\nChoix : ");
            int choix;
            if (!int.TryParse(Console.ReadLine(), out choix)) return;

            if (choix < 1 || choix > liste.Count) return;

            var med = liste[choix - 1];

            Console.Write("Quantité : ");
            int qte;
            if (!int.TryParse(Console.ReadLine(), out qte)) qte = 1;

            panier.Add(new Medicament
            {
                Nom = med.Nom,
                Prix = med.Prix,
                Quantite = qte
            });

            Console.WriteLine("Ajouté !");
            Thread.Sleep(800);
        }

        static void ModifierQuantite(List<Medicament> panier)
        {
            if (panier.Count == 0) return;

            Console.Write("\nChoisir médicament : ");
            int index;
            if (!int.TryParse(Console.ReadLine(), out index)) return;

            if (index < 1 || index > panier.Count) return;

            Console.Write("Nouvelle quantité : ");
            int qte;
            if (!int.TryParse(Console.ReadLine(), out qte)) return;

            panier[index - 1].Quantite = qte;

            Console.WriteLine("Modifié !");
            Thread.Sleep(800);
        }

        static void SupprimerMedicament(List<Medicament> panier)
        {
            if (panier.Count == 0) return;

            Console.Write("\nChoisir médicament à supprimer : ");
            int index;
            if (!int.TryParse(Console.ReadLine(), out index)) return;

            if (index < 1 || index > panier.Count) return;

            panier.RemoveAt(index - 1);

            Console.WriteLine("Supprimé !");
            Thread.Sleep(800);
        }

        static void Animation(string message)
        {
            Console.Write(message);

            for (int i = 0; i < 3; i++)
            {
                Thread.Sleep(500);
                Console.Write(".");
            }

            Console.WriteLine("\n");
        }
    }
}