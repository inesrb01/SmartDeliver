﻿using System;

namespace SmartDeliver2.Services
{
    public class LivraisonExpress : ILivraison
    {
        public double CalculerTotal(double prixBase)
        {
            return prixBase + 10; // exemple
        }
    }
}