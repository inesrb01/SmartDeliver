﻿using SmartDeliver2.Models;
using SmartDeliver2.Repositories;

namespace SmartDeliver2.Services
{
    public class CommandeService
    {
        private CommandeRepository _repository;

        public CommandeService()
        {
            _repository = new CommandeRepository();
        }

        public void CreerCommande(Commande commande, string type)
        {
            var livraison = LivraisonFactory.Creer(type);

            // OPTIONNEL si tu ajoutes Prix dans Commande
            // commande.Prix = livraison.CalculerPrix();

            _repository.Ajouter(commande);
        }
    }
}