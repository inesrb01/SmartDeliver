﻿namespace SmartDeliver2.Services
{
    public class LivraisonStandard : ILivraison
    {
        public double CalculerTotal(double prixBase)
        {
            return prixBase + 5;
        }
    }
}