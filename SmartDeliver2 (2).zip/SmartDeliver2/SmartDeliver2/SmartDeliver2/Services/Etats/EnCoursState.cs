﻿using SmartDeliver2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartDeliver2.Services.Etats
{
    public class EnCoursState : IEtatCommande
    {
        public void ProchainEtat(Commande commande)
        {
            commande.SetEtat(new LivreeState());
        }

        public string NomEtat()
        {
            return "En cours";
        }
    }
}
