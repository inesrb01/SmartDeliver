﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SmartDeliver2.Models;

namespace SmartDeliver2.Services.Etats
{
    public class LivreeState : IEtatCommande
    {
        public void ProchainEtat(Commande commande)
        {
            // Fin
        }

        public string NomEtat()
        {
            return "Livrée";
        }
    }
}
