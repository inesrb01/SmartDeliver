﻿using SmartDeliver2.Services;
using SmartDeliver2.Services.Etats;
using SmartDeliver2.Services.Observers;
using System.Collections.Generic;

namespace SmartDeliver2.Models
{
    public class Commande
    {
        public string Client { get; set; }
        public string Adresse { get; set; }

        public IEtatCommande Etat { get; private set; }

        public List<Medicament> Medicaments { get; set; } = new List<Medicament>();

        private List<IObserver> observers = new List<IObserver>();

        public void AjouterObserver(IObserver observer)
        {
            observers.Add(observer);
        }

        public void Notifier(string message)
        {
            foreach (var obs in observers)
            {
                obs.Update(message);
            }
        }

        public void SetEtat(IEtatCommande etat)
        {
            Etat = etat;
            Notifier("Changement d'état : " + Etat.NomEtat());
        }

        public void ProchainEtat()
        {
            Etat.ProchainEtat(this);
            Notifier("Nouvel état : " + Etat.NomEtat());
        }
    }
}