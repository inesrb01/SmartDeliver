﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartDeliver2.Models
{
    public class Medicament
    {
        public string Nom { get; set; }
        public double Prix { get; set; }
        public int Quantite { get; set; }
    }
}
