﻿using SmartDeliver2.Core;
using SmartDeliver2.Models;
using System.Data.SqlClient;

namespace SmartDeliver2.Repositories
{
    public class CommandeRepository
    {
        public void Ajouter(Commande commande)
        {
            using (SqlConnection conn = DbManager.Instance.GetConnection())
            {
                string query = "INSERT INTO Commande (Client, Adresse) VALUES (@Client, @Adresse)";

                SqlCommand cmd = new SqlCommand(query, conn);

                cmd.Parameters.AddWithValue("@Client", commande.Client);
                cmd.Parameters.AddWithValue("@Adresse", commande.Adresse);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }
    }
}