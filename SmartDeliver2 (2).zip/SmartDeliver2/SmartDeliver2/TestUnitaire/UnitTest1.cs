﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using SmartDeliver2.Models;
using SmartDeliver2.Services;
using SmartDeliver2.Services.Etats;

namespace TestUnitaire
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Test_LivraisonStandard_Prix()
        {
            var livraison = new LivraisonStandard();

            double prix = livraison.CalculerTotal(0);

            Assert.AreEqual(5.0, prix);
        }

        [TestMethod]
        public void Test_Commande_ChangeEtat()
        {
            var commande = new Commande();

            commande.SetEtat(new EnAttenteState());
            commande.ProchainEtat();

            Assert.IsInstanceOfType(commande.Etat, typeof(EnCoursState));
        }
    }
}