namespace SmartDeliver.Models
{
    public class Commande
    {
        public int Id { get; set; }
        public int ClientId { get; set; }
        public string Adresse { get; set; }
        public double Prix { get; set; }
        public string Statut { get; set; }
    }
}