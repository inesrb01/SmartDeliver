using System.Data.SqlClient;

namespace SmartDeliver.Core
{
    public class DbManager
    {
        private static DbManager _instance;
        private string _connectionString =
            @"Server=(localdb)\MSSQLLocalDB;Database=SmartDeliverDB;Trusted_Connection=True;";

        private DbManager() { }

        public static DbManager Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new DbManager();
                return _instance;
            }
        }

        public SqlConnection GetConnection()
        {
            return new SqlConnection(_connectionString);
        }
    }
}