namespace SmartDeliver.Services
{
    public interface ILivraison
    {
        double CalculerTotal(double prixBase);
    }
}