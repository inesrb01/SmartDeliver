namespace SmartDeliver.Services
{
    public class LivraisonFactory
    {
        public static ILivraison Creer(string type)
        {
            if (type == "Express")
                return new LivraisonExpress();

            return new LivraisonStandard();
        }
    }
}