namespace SmartDeliver.Services
{
    public class LivraisonExpress : ILivraison
    {
        public double CalculerTotal(double prixBase)
        {
            return prixBase + 25;
        }
    }
}