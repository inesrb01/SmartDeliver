using SmartDeliver.Models;
using SmartDeliver.Repositories;

namespace SmartDeliver.Services
{
    public class CommandeService
    {
        private CommandeRepository _repository;

        public CommandeService()
        {
            _repository = new CommandeRepository();
        }

        public void CreerCommande(Commande commande, string typeLivraison)
        {
            var livraison = LivraisonFactory.Creer(typeLivraison);

            commande.Prix = livraison.CalculerTotal(commande.Prix);
            commande.Statut = "En attente";

            _repository.Ajouter(commande);
        }
    }
}