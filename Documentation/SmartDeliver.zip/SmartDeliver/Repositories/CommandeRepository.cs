using SmartDeliver.Models;
using SmartDeliver.Core;
using System.Data.SqlClient;

namespace SmartDeliver.Repositories
{
    public class CommandeRepository
    {
        public void Ajouter(Commande commande)
        {
            using (SqlConnection conn = DbManager.Instance.GetConnection())
            {
                conn.Open();

                string query = @"INSERT INTO Commande 
                                 (ClientId, Adresse, Prix, Statut)
                                 VALUES (@ClientId, @Adresse, @Prix, @Statut)";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@ClientId", commande.ClientId);
                cmd.Parameters.AddWithValue("@Adresse", commande.Adresse);
                cmd.Parameters.AddWithValue("@Prix", commande.Prix);
                cmd.Parameters.AddWithValue("@Statut", commande.Statut);

                cmd.ExecuteNonQuery();
            }
        }
    }
}