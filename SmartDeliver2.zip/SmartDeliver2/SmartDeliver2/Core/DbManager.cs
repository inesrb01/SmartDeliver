﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartDeliver2.Core
{
    public class DbManager
    {
        private static DbManager _instance;
        private string _connectionString =
            @"Server=(localdb)\MSSQLLocalDB;Database=SmartDeliverDB;Trusted_Connection=True;";

        private DbManager() { }

        public static DbManager Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new DbManager();
                return _instance;
            }
        }

        public SqlConnection GetConnection()
        {
            return new SqlConnection(_connectionString);
        }
    }
}
