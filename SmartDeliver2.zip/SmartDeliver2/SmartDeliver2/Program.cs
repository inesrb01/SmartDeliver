﻿using SmartDeliver2.Models;
using SmartDeliver2.Services.Observers;
using System;

namespace SmartDeliver2
{
    class Program
    {
        static void Main(string[] args)
        {
            Commande commande = new Commande();
            ClientObserver client = new ClientObserver();
            commande.AjouterObserver(client);

            bool continuer = true;

            while (continuer)
            {
                Console.WriteLine("\n===== SMARTDELIVER =====");
                Console.WriteLine("1. Voir statut");
                Console.WriteLine("2. Avancer statut");
                Console.WriteLine("3. Quitter");
                Console.Write("Choix : ");

                string choix = Console.ReadLine();

                switch (choix)
                {
                    case "1":
                        Console.WriteLine("Statut actuel : " + commande.GetStatut());
                        break;

                    case "2":
                        commande.AvancerEtat();
                        break;

                    case "3":
                        continuer = false;
                        break;

                    default:
                        Console.WriteLine("Choix invalide.");
                        break;
                }
            }
        }
    }
}