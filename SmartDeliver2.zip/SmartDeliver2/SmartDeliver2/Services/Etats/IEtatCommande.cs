﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SmartDeliver2.Models;

namespace SmartDeliver2.Services.Etats
{
    public interface IEtatCommande
    {
        void Traiter(Commande commande);
        string GetStatut();
    }
}
