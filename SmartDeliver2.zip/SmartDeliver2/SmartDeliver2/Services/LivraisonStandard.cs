﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartDeliver2.Services
{
    public class LivraisonStandard : ILivraison
    {
        public double CalculerTotal(double prixBase)
        {
            return prixBase + 10;
        }
    }
}
