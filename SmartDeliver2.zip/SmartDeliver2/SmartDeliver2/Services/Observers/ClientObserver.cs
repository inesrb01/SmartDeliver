﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartDeliver2.Services.Observers
{
    public class ClientObserver : IObserver
    {
        public void Update(string message)
        {
            Console.WriteLine("Notification client : " + message);
        }
    }
}
