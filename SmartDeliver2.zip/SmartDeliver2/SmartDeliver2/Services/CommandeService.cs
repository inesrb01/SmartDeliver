﻿using SmartDeliver2.Models;
using SmartDeliver2.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartDeliver2.Services
{
    public class CommandeService
    {
        private CommandeRepository _repository;

        public CommandeService()
        {
            _repository = new CommandeRepository();
        }

        public void CreerCommande(Commande commande, string typeLivraison)
        {
            var livraison = LivraisonFactory.Creer(typeLivraison);

            commande.Prix = livraison.CalculerTotal(commande.Prix);

            _repository.Ajouter(commande);
        }
    }
}
