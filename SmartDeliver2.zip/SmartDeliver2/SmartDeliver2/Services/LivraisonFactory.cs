﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartDeliver2.Services
{
    public class LivraisonFactory
    {
        public static ILivraison Creer(string type)
        {
            if (type == "Express")
                return new LivraisonExpress();

            return new LivraisonStandard();
        }
    }
}
