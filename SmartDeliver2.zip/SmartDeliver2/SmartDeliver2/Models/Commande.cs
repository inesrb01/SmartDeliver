﻿using SmartDeliver2.Services;
using SmartDeliver2.Services.Etats;
using SmartDeliver2.Services.Observers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartDeliver2.Models
{
    public class Commande
    {
        // Propriétés métier
        public int Id { get; set; }
        public int ClientId { get; set; }
        public string Adresse { get; set; }
        public double Prix { get; set; }

        // ----- STATE PATTERN -----
        private IEtatCommande _etat;

        // ----- OBSERVER PATTERN -----
        private List<IObserver> _observers = new List<IObserver>();

        public Commande()
        {
            _etat = new EnAttenteState();
        }

        // ========================
        // STATE METHODS
        // ========================

        public void SetEtat(IEtatCommande etat)
        {
            _etat = etat;
        }

        public void AvancerEtat()
        {
            _etat.Traiter(this);
            Notifier("Le statut est maintenant : " + GetStatut());
        }

        public string GetStatut()
        {
            return _etat.GetStatut();
        }

        // ========================
        // OBSERVER METHODS
        // ========================

        public void AjouterObserver(IObserver observer)
        {
            _observers.Add(observer);
        }

        private void Notifier(string message)
        {
            foreach (var observer in _observers)
            {
                observer.Update(message);
            }
        }
    }
}